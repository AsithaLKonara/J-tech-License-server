# License Keys & Tokens

- license_keys.yaml: simple offline keys (fallback/demo)
- public_key.pem: Ed25519 public key used to verify signed tokens (add your own)

Recommended: Use signed tokens and remove YAML keys for production.

